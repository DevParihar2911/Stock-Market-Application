const toggleThemeElement = document.querySelector("#styleCSS");
const toggleButtonElement = document.querySelector("#toggle-button");
const toggleSpanElement = toggleButtonElement.querySelector("span");

function changeTheme() {
  toggleButtonElement.addEventListener("click", (event) => {
    let theme = toggleThemeElement.href.split("/")[3];
    if (theme === "styleLight.css") {
      theme = "styleDark.css";
    } else if (theme === "styleDark.css") {
      theme = "styleLight.css";
    }
    toggleThemeElement.setAttribute("href", theme);
  });
}

changeTheme();
